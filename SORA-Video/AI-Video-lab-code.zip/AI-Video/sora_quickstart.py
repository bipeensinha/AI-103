# ============================================================
# SORA 2 QUICKSTART - text-to-video from a Python script
# ============================================================
import os
import time

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(
    base_url=f"{os.environ['AZURE_OPENAI_ENDPOINT'].rstrip('/')}/openai/v1/",
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
)

prompt = (
    "A cinematic shot of a spaceship flying through a nebula "
    "filled with colorful cosmic clouds."
)

# 1. Start the job (returns immediately with a job id)
video = client.videos.create(
    model=os.getenv("AZURE_OPENAI_DEPLOYMENT", "sora-2"),
    prompt=prompt,
    size="1280x720",   # "1280x720" (16:9) or "720x1280" (9:16)
    seconds="8",       # "4", "8" or "12"
)
print(f"Job started: {video.id}")

# 2. Poll until the job finishes
while video.status in ("queued", "in_progress"):
    time.sleep(10)
    video = client.videos.retrieve(video.id)
    print(f"  {video.status} {video.progress or 0}%")

# 3. Download the MP4
if video.status == "completed":
    content = client.videos.download_content(video.id, variant="video")
    content.write_to_file("output.mp4")
    print("Video generated: output.mp4")
else:
    print(f"Job ended with status {video.status}: {video.error}")
