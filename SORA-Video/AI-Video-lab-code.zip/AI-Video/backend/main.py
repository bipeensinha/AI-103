# ============================================================
# AI VIDEO STUDIO
# Sora 2 + Microsoft Foundry
# ============================================================

import os

from dotenv import load_dotenv
from fastapi import FastAPI, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from openai import OpenAI

# ============================================================
# 1. LOAD ENVIRONMENT VARIABLES
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "..", ".env"))

ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "sora-2")

if not all([ENDPOINT, API_KEY]):
    raise RuntimeError("Missing values in .env - check endpoint and key.")

# ============================================================
# 2. CREATE THE OPENAI CLIENT (AZURE v1 API)
# ============================================================
# Sora 2 uses the Azure OpenAI v1 API, so no api_version is needed.
# The base URL is your Azure OpenAI endpoint + /openai/v1/

client = OpenAI(
    base_url=f"{ENDPOINT.rstrip('/')}/openai/v1/",
    api_key=API_KEY,
)

# ============================================================
# 3. CREATE THE FASTAPI APP AND ALLOW THE FRONTEND (CORS)
# ============================================================

app = FastAPI(title="AI Video Studio API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5501", "http://127.0.0.1:5501"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_SIZES = {"1280x720", "720x1280"}   # 16:9 landscape, 9:16 portrait
ALLOWED_SECONDS = {"4", "8", "12"}
VIDEO_DIR = os.path.join(BASE_DIR, "videos")
os.makedirs(VIDEO_DIR, exist_ok=True)

# ============================================================
# 4. HEALTH CHECK
# ============================================================

@app.get("/")
def health():
    return {"status": "ok", "model": DEPLOYMENT}

# ============================================================
# 5. START A VIDEO JOB
# ============================================================

@app.post("/generate")
def generate_video(
    prompt: str = Form(...),
    size: str = Form("1280x720"),
    seconds: str = Form("8"),
):
    prompt = prompt.strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="Prompt is required.")
    if size not in ALLOWED_SIZES:
        raise HTTPException(status_code=400, detail=f"Unsupported size: {size}")
    if seconds not in ALLOWED_SECONDS:
        raise HTTPException(status_code=400, detail=f"Unsupported duration: {seconds}")

    try:
        video = client.videos.create(
            model=DEPLOYMENT,
            prompt=prompt,
            size=size,
            seconds=seconds,
        )
    except Exception as err:
        raise HTTPException(status_code=502, detail=f"Model call failed: {err}")

    # Sora works asynchronously: return the job id straight away
    return {"id": video.id, "status": video.status}

# ============================================================
# 6. CHECK JOB STATUS
# ============================================================

@app.get("/status/{video_id}")
def video_status(video_id: str):
    try:
        video = client.videos.retrieve(video_id)
    except Exception as err:
        raise HTTPException(status_code=502, detail=f"Status check failed: {err}")

    error = None
    if video.status == "failed" and video.error:
        error = video.error.message

    return {
        "id": video.id,
        "status": video.status,          # queued | in_progress | completed | failed
        "progress": video.progress or 0,  # 0-100
        "error": error,
    }

# ============================================================
# 7. DOWNLOAD THE FINISHED MP4
# ============================================================

@app.get("/video/{video_id}")
def get_video(video_id: str):
    file_path = os.path.join(VIDEO_DIR, f"{video_id}.mp4")

    # Download once from Foundry, then serve the local copy
    if not os.path.exists(file_path):
        try:
            content = client.videos.download_content(video_id, variant="video")
            content.write_to_file(file_path)
        except Exception as err:
            raise HTTPException(status_code=502, detail=f"Download failed: {err}")

    return FileResponse(file_path, media_type="video/mp4", filename="ai-video.mp4")
