// ------------------------------------------------------------
// API
// ------------------------------------------------------------
const API_URL = "http://localhost:8001";
const POLL_MS = 5000; // check job status every 5 seconds

// ------------------------------------------------------------
// ELEMENTS
// ------------------------------------------------------------
const promptInput = document.getElementById("prompt");
const sizeInput = document.getElementById("size");
const secondsInput = document.getElementById("seconds");
const generateButton = document.getElementById("generateBtn");
const statusText = document.getElementById("status");
const progressWrap = document.getElementById("progressWrap");
const progressBar = document.getElementById("progressBar");
const resultVideo = document.getElementById("result");
const placeholder = document.getElementById("placeholder");
const downloadLink = document.getElementById("download");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function setProgress(pct) {
  progressWrap.hidden = false;
  progressBar.style.width = `${pct}%`;
}

// ------------------------------------------------------------
// GENERATE
// ------------------------------------------------------------
async function generateVideo() {
  const prompt = promptInput.value.trim();
  if (!prompt) {
    statusText.textContent = "Please enter a prompt.";
    return;
  }

  const formData = new FormData();
  formData.append("prompt", prompt);
  formData.append("size", sizeInput.value);
  formData.append("seconds", secondsInput.value);

  generateButton.disabled = true;
  generateButton.textContent = "Generating...";
  downloadLink.hidden = true;
  setProgress(0);
  statusText.textContent = "Submitting job to Sora 2...";

  try {
    // 1. Start the job
    const startRes = await fetch(`${API_URL}/generate`, { method: "POST", body: formData });
    const job = await startRes.json();
    if (!startRes.ok) throw new Error(job.detail || "Request failed");

    // 2. Poll until the job finishes (usually 1-5 minutes)
    let status = job.status;
    while (status === "queued" || status === "in_progress") {
      await sleep(POLL_MS);
      const res = await fetch(`${API_URL}/status/${job.id}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Status check failed");
      status = data.status;
      if (status === "failed") throw new Error(data.error || "Video generation failed");
      setProgress(data.progress);
      statusText.textContent = `${status === "queued" ? "Queued" : "Rendering"}... ${data.progress}%`;
    }

    // 3. Show the finished video
    const videoUrl = `${API_URL}/video/${job.id}`;
    resultVideo.src = videoUrl;
    resultVideo.hidden = false;
    placeholder.hidden = true;
    downloadLink.href = videoUrl;
    downloadLink.hidden = false;
    setProgress(100);
    statusText.textContent = "Done!";
  } catch (error) {
    statusText.textContent = `Error: ${error.message}`;
  } finally {
    generateButton.disabled = false;
    generateButton.textContent = "Generate Video";
  }
}

generateButton.addEventListener("click", generateVideo);
